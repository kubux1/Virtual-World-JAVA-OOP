package wojskarakietowe;


/**
 * Created by Kuba on 2016-03-17.
 */
public class WyrzutniaRakietAtomowych {

    void ognia(){
        this.umiescGlowice();
        this.wycelujMiasto();
        this.uruchomSilmik();
        System.out.println("BUM!");
    }
    private void wycelujMiasto(){}
    private void uruchomSilmik(){}
    private void umiescGlowice(){}
}
