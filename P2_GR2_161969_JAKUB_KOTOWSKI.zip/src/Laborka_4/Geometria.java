package Laborka_4;

/**
 * Created by Kuba on 2016-04-02.
 */
interface Geometria {
    double pole();
    double obwod();
}
