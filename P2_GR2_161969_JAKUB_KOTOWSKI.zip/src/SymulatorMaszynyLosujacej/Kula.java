package SymulatorMaszynyLosujacej;

/**
 * Created by Kuba on 2016-03-17.
 */
public class Kula {
     public int LiczbaNaKuli;
   public  boolean czy_dociazona;
}
