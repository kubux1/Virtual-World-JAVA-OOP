package Laborka_4;

/**
 * Created by Kuba on 2016-04-02.
 */
public class Wyjatek extends Exception {
    public Wyjatek(String name){
        super("Autor programu: Jakub Kotowski");
    }
}
